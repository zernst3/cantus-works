Codebase Inspection - Product Export
=====================================

This ZIP holds the files below. All of them come from the same inspection.

camerata-inspection-hearth.pdf
  The report to read first. It has the cover, the executive summary, the scorecard by
  area, the severity by effort matrix, the problems with their citations and fixes,
  what is healthy, the dependency snapshot and how the inspection was done. It is
  written for a board, a buyer or a decision maker. Problems ruled out are left out
  and counted once, in the methodology section.

camerata-inspection-hearth-findings.xlsx
  The complete working list for the engineers doing the fixes. Open the Start Here sheet
  first: it lists the sheets and says what each one holds, and the Glossary sheet says
  what every word and column means. The Fix Plan sheet has one row for each fix, in the
  order to do them. The All Problems sheet has every problem once, as a row to
  sort and filter, with the place it was seen and what to do there. The Needs a Decision sheet
  holds the problems a reviewer must rule on before anyone acts on them. Your Conventions,
  Departures and Dependencies say what the code already does consistently,
  where it departs from that and which packages it depends on are vulnerable. The
  Rules Checked sheet lists every rule we checked, whether it found anything or not,
  the Ruled Out sheet gives the reason each problem was ruled out and the
  Not Checked sheet lists what we could not or did not check, so nothing is dropped
  silently. The last sheets are for reviewers: All Source Rows, Reviewer Decisions and
  How Problems Were Grouped.

findings.json
  Every row that was not ruled out, of every kind: the rows behind All Problems,
  Your Conventions and Not Checked together, before the All Problems sheet shows each
  problem once. For scripts, CI and other tools: severity, area, repo, path and line,
  the code seen, the explanation, the fix, the decision so far, effort, confidence,
  citation and more, wrapped with the report's summary counts.

decisions.json
  Every decision record the report was reviewed with: what was ruled on which place or
  group of places, and whether a reason was recorded. The Reviewer Decisions sheet of the
  workbook is the same list.

csv/ and json/
  One file for each table of the workbook, as CSV and as JSON, for tools that do not
  read Excel. The all-findings files are the exception: they hold the same rows as
  findings.json, as one flat table.

manifest.json
  The list of the files in this ZIP with a checksum for each.

csv/tickets.csv
  One ticket for each fix (one kind of problem with one cause) that still has places to
  change. A place ruled out or accepted as a risk is on no ticket.
  Columns: Title, Description, Priority, Labels, Estimate, Fix id, Places
  and Place list. Places counts the places of the ticket and Place list names the
  first 50, then points to the All Problems sheet. Fix id is the Fix id
  of the All Problems sheet. To import the file:
  - Jira: map Title to Summary, Description to Description, Priority to Priority
    (Highest, High, Medium or Low), Labels to Labels (split on commas) and Place list to
    any text field. Estimate is text, not a duration.
  - Linear: Title, Description and Labels map to the fields of the same name.
    Priority maps as Highest to Urgent, High to High, Medium to Medium and Low to
    Low.
  - GitHub Issues: map Title to Title, Description to Body and Labels to Labels
    (comma separated). Priority and Estimate have no field there, so put them in
    the body or drop them.
  Keep Fix id in a custom field or in the body: it is the Fix id to filter the
  All Problems sheet on.
